from __future__ import annotations
import os, re
from datetime import datetime, timezone
from typing import Optional, List
import pandas as pd

DATASET = os.getenv("DATASET", "GLBX.MDP3").strip()
SCHEMA  = os.getenv("SCHEMA",  "trades").strip()  # default to trades; we resample to 1m

def _available_end_from_error(e: Exception) -> Optional[datetime]:
    m = re.search(r"available up to '([^']+)'", str(e))
    if not m: return None
    try: return datetime.fromisoformat(m.group(1)).astimezone(timezone.utc)
    except Exception: return None

def _normalize_to_1m(df: pd.DataFrame) -> pd.DataFrame:
    # choose a time column
    for c in ("timestamp","ts_event","ts_recv","time"):
        if c in df.columns:
            idx = pd.to_datetime(df[c], utc=True)
            break
    else:
        raise ValueError("No time column found.")
    x = df.copy(); x.index = idx
    out = x.resample("1min").agg({
        "open":"first","high":"max","low":"min","close":"last","volume":"sum"
    }).dropna(how="any").reset_index().rename(columns={"index":"timestamp"})
    if out["timestamp"].dtype.tz is None:
        out["timestamp"] = out["timestamp"].dt.tz_localize("UTC")
    return out[["timestamp","open","high","low","close","volume"]]

def _fetch_databento(symbol: str, start: datetime, end: datetime) -> Optional[pd.DataFrame]:
    key = os.getenv("DATABENTO_API_KEY", "").strip()
    if not key: return None
    from databento import Historical
    client = Historical(key=key)

    # Try a few direct strings that commonly work for CME NQ; first item is env SYMBOL
    s = (symbol or "").upper()
    root = re.sub(r"[^A-Z]+.*$", "", s) or "NQ"
    candidates: List[str] = list(dict.fromkeys([
        s, "CME.NQ", root, "NQ", "NQZ5"
    ]))

    def query(sym: str, e_end: datetime):
        return client.timeseries.get_range(
            dataset=DATASET, schema=SCHEMA, symbols=sym,
            start=start.replace(tzinfo=timezone.utc).isoformat(),
            end=e_end.replace(tzinfo=timezone.utc).isoformat()
        ).to_df()

    last_err = None
    for sym in candidates:
        try:
            df = query(sym, end)
        except Exception as e:
            last_err = e
            avail = _available_end_from_error(e)
            if avail and avail > start:
                try:
                    df = query(sym, avail)
                except Exception as e2:
                    last_err = e2
                    continue
            else:
                continue
        if df is None or df.empty:
            continue
        try:
            out = _normalize_to_1m(df)
            print(f"[databento] OK dataset={DATASET} schema={SCHEMA} symbol={sym} rows={len(out)} "
                  f"from={out['timestamp'].iloc[0]} to={out['timestamp'].iloc[-1]}")
            return out
        except Exception as e:
            last_err = e
            continue

    if last_err:
        print(f"[databento] error: {last_err}")
    else:
        print(f"[databento] no rows from candidates={candidates}")
    return None
