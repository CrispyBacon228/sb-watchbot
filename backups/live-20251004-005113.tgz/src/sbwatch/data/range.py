from __future__ import annotations
from datetime import datetime, timezone
import pandas as pd
from ._db_fetch import _fetch_databento

def get_ohlcv_range_1m(symbol: str, start_utc: datetime, end_utc: datetime) -> pd.DataFrame:
    if start_utc.tzinfo is None: start_utc = start_utc.replace(tzinfo=timezone.utc)
    if end_utc.tzinfo is None:   end_utc   = end_utc.replace(tzinfo=timezone.utc)
    df = _fetch_databento(symbol, start_utc, end_utc)
    if df is None:
        # synthetic fallback for wiring tests
        import numpy as np
        rng = pd.date_range(start_utc, end_utc, freq="1min", tz="UTC", inclusive="left")
        base = 20000.0
        prices = base + np.cumsum(np.random.randn(len(rng)))
        df = pd.DataFrame({
            "timestamp": rng,
            "open": prices,
            "high": prices + np.random.rand(len(rng))*2,
            "low":  prices - np.random.rand(len(rng))*2,
            "close": prices + (np.random.rand(len(rng))-0.5)*1.0,
            "volume": np.random.randint(10, 500, size=len(rng)),
        })
    return df
