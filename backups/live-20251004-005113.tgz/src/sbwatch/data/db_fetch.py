import os
import re
import time
from datetime import datetime, timedelta, timezone

import pandas as pd
import pytz
from dotenv import load_dotenv
from databento import Historical

load_dotenv("/opt/sb-watchbot/.env")

API_KEY  = os.environ["DATABENTO_API_KEY"]
DATASET  = os.environ["DATASET"]
SCHEMA   = os.environ["SCHEMA"]
SYMBOL   = os.environ["SYMBOL"]
DIV      = int(os.getenv("PRICE_DIVISOR", "1"))

client = Historical(API_KEY)
NY = pytz.timezone("America/New_York")

def _normalize_time(df: pd.DataFrame) -> pd.DataFrame:
    """
    Ensure a 'timestamp' column exists:
    - prefer existing columns: timestamp, time, ts_event, ts_recv, ts_out, ts_exchange
    - otherwise pull from DatetimeIndex (named or unnamed)
    """
    if df is None or df.empty:
        return df

    # 1) Column case
    for c in ("timestamp", "time", "ts_event", "ts_recv", "ts_out", "ts_exchange"):
        if c in df.columns:
            if c != "timestamp":
                df = df.rename(columns={c: "timestamp"})
            break
    else:
        # 2) Index case
        if isinstance(df.index, pd.DatetimeIndex):
            idx_name = df.index.name  # could be 'ts_event' or None
            df = df.reset_index()
            if idx_name and idx_name in df.columns:
                df = df.rename(columns={idx_name: "timestamp"})
            elif "index" in df.columns:
                df = df.rename(columns={"index": "timestamp"})
            else:
                # last resort: create from first column if it's datetime-like
                first_col = df.columns[0]
                if pd.api.types.is_datetime64_any_dtype(df[first_col]):
                    df = df.rename(columns={first_col: "timestamp"})
                else:
                    raise KeyError(
                        f"Could not find/derive time column from index; cols={list(df.columns)}"
                    )
        else:
            raise KeyError(
                f"No time column and index is not DatetimeIndex; cols={list(df.columns)}"
            )

    # 3) Parse as UTC
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True, errors="coerce")
    return df

def _apply_divisor(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return df
    for col in ("open", "high", "low", "close"):
        if col in df.columns:
            df[col] = df[col] / DIV
    return df

def parse_available_end(e: Exception):
    m = re.search(r"\('([^']+)'\)", str(e))
    if not m:
        return None
    try:
        return datetime.fromisoformat(m.group(1)).astimezone(timezone.utc)
    except Exception:
        return None

def ny_close_utc(dt_utc: datetime) -> datetime:
    d = dt_utc.astimezone(NY)
    return NY.localize(datetime(d.year, d.month, d.day, 16, 0)).astimezone(timezone.utc)

def fetch_range(start: datetime, end: datetime) -> pd.DataFrame:
    """
    Historical range fetch that mirrors your working snippet.
    """
    df = client.timeseries.get_range(
        dataset=DATASET,
        schema=SCHEMA,
        symbols=[SYMBOL],
        start=start,
        end=end,
    ).to_df()

    if df is None or df.empty:
        return pd.DataFrame()

    df = _normalize_time(df)
    df = _apply_divisor(df)
    return df

def fetch_live_loop():
    """
    Poll the latest available minute until NY close.
    """
    print(f"Live watch → {DATASET}/{SCHEMA} {SYMBOL}")
    last_ts = None
    while True:
        now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        end = min(ny_close_utc(now), now)
        start = end - timedelta(minutes=2)
        try:
            df = fetch_range(start, end)
        except Exception as e:
            # try clamping to available_end if provided
            ae = parse_available_end(e)
            if ae:
                end = ae.replace(second=0, microsecond=0)
                start = end - timedelta(minutes=2)
                df = fetch_range(start, end)
            else:
                print("err:", e)
                time.sleep(5)
                continue

        if df is None or df.empty:
            time.sleep(5)
            continue

        bar = df.iloc[-1]
        ts = str(bar["timestamp"])
        if ts != last_ts:
            last_ts = ts
            print(
                f"{ts}  O:{bar.get('open')}  H:{bar.get('high')}  "
                f"L:{bar.get('low')}  C:{bar.get('close')}  V:{bar.get('volume')}"
            )
        time.sleep(5)
