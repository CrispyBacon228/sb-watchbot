from __future__ import annotations
from datetime import datetime, timedelta, timezone
import pandas as pd
from ._db_fetch import _fetch_databento

def get_ohlcv_1m(symbol: str, lookback_mins: int = 600) -> pd.DataFrame:
    end = datetime.now(timezone.utc)
    start = end - timedelta(minutes=lookback_mins + 5)
    df = _fetch_databento(symbol, start, end)
    if df is None:
        # synthetic fallback for wiring tests
        import numpy as np
        rng = pd.date_range(end - timedelta(minutes=lookback_mins), end, freq="1min", tz="UTC")
        base = 20000.0
        prices = base + np.cumsum(np.random.randn(len(rng)))
        df = pd.DataFrame({
            "timestamp": rng,
            "open": prices,
            "high": prices + np.random.rand(len(rng))*2,
            "low":  prices - np.random.rand(len(rng))*2,
            "close": prices + (np.random.rand(len(rng))-0.5)*1.0,
            "volume": np.random.randint(10, 500, size=len(rng)),
        })
    return df
